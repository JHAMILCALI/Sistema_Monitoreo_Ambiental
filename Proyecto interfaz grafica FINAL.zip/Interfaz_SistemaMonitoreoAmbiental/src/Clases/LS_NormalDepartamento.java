package Clases;

public class LS_NormalDepartamento extends ListaSimpleDepartamento{
	public LS_NormalDepartamento() {
		super();
	}
	
	public boolean esVacia() {
		if(P == null) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public void adiPrincipio(Departamento z) {
		NodoDepartamento nuevo = new NodoDepartamento();
		nuevo.setDepartamento(z);
		nuevo.setSig(P); // el siguiente del nodo apunta a nodo raiz
		P = nuevo;		 // P apunta a nuevo
	}
	
	public void adiFinal(Departamento z) {
		NodoDepartamento nuevo = new NodoDepartamento();
		nuevo.setDepartamento(z);
		
		if(esVacia()) {
			P = nuevo;     //p apunta a nuevo
		}
		else {
			NodoDepartamento R = P;
			while(R.getSig() != null) {
				R = R.getSig();
			}
			R.setSig(nuevo);
			
		}
	}
	
	public void mostrar() {
		NodoDepartamento R = P;  //R apunta a la raiz P
		while(R != null) {
			R.getDepartamento().mostrar();
			System.out.println("*************************************************************************************");
			R = R.getSig();
		}
	}
	
	public int nroNodos() {
		NodoDepartamento R = P;
		int c = 0;
		if(this.esVacia()) {
			return 0;
		}
		else {
			while(R != null) {
				c++;
				R = R.getSig();
			}
		}
		return c;
	}
	
	public NodoDepartamento eliPrincipio() {
		NodoDepartamento x = new NodoDepartamento();
		if(!esVacia()) {
			x = P;
			P = P.getSig();
			x.setSig(null);
		}
		return x;
	}
	
	public NodoDepartamento eliFinal() {
		NodoDepartamento x = new NodoDepartamento();
		if(!esVacia()) {
			if(nroNodos() == 1) {
				x = P;
				P = null;
			}
			else {
				NodoDepartamento R = P;
				NodoDepartamento S = P;
				while(R.getSig() != null) {
					S = R;      //S apunta a R
					R = R.getSig();  //R apunta al siguiente de R
				}
				x = R;
				S.setSig(null);
			}
		}
		return x;
	}
	
	public void leer1(int n) {
		for(int i = 1; i <= n; i++) {
			Departamento z = new Departamento();
			z.leer();
			adiPrincipio(z);
		}
	}
        
        
        
          public void leer1(){
            ColaSimpleGobierno G = new ColaSimpleGobierno();
		G.adi(new Gobierno("Ivan Arias","La Paz",2500));
		G.adi(new Gobierno("Christian Camara","Beni",1250));
		G.adi(new Gobierno("Enrique Leaño","Chuquisaca",1850));
		G.adi(new Gobierno("Jhonny Fernandez","Santa Cruz",3500));
		G.adi(new Gobierno("Lucía Reis","Pando",1500));
		G.adi(new Gobierno("Johnny Torres","Tarija",1300));
		G.adi(new Gobierno("Manfred Reyes","Cochabamba",1800));
		G.adi(new Gobierno("Adhemar Wilcarani","Oruro",1400));
		G.adi(new Gobierno("Jhonny Llally","Potosi",1600));
		PilaMonitoreador M = new PilaMonitoreador();
		M.adi(new Monitoreador("Carlos Martinez","Lp02"));
		M.adi(new Monitoreador("Maria Boutier","Lp02"));
		M.adi(new Monitoreador("Sergio Luque","Ch01"));
		M.adi(new Monitoreador("Viviana Pereira","Be08"));
		M.adi(new Monitoreador("Luis Roque","Scz07"));
		M.adi(new Monitoreador("Tina Velazquez","Ch1"));
		M.adi(new Monitoreador("Zoe Miranda","Be08"));
		M.adi(new Monitoreador("Gabriel Alvarez","Scz07"));
		
		
		M.adi(new Monitoreador("Malena Sanchez","Pt05"));
		M.adi(new Monitoreador("Caleb Herrera","Cbba03"));
		M.adi(new Monitoreador("Ariana Zabala","Pnd09"));
		M.adi(new Monitoreador("Sandra Cuba","Tja06"));
		M.adi(new Monitoreador("Yamil Rojas","Pt05"));
		M.adi(new Monitoreador("Alex Marquez","Tja06"));
		M.adi(new Monitoreador("Limbert Kahuasa","Or04"));
		M.adi(new Monitoreador("Diana Kellen","Cbba03"));
		M.adi(new Monitoreador("Anahi Zambrana","Or04"));
		M.adi(new Monitoreador("Helena Arancibia","Pnd09"));

		System.out.println();
		G.mostrar();
		M.mostrar();
		
		
		LS_NormalTemperatura TEM1 = new LS_NormalTemperatura();
		TEM1.adiFinal(new Temperatura(56));
		TEM1.adiFinal(new Temperatura(-12));
		TEM1.adiFinal(new Temperatura(-10));
		TEM1.adiFinal(new Temperatura(32));
		TEM1.adiFinal(new Temperatura(20));
		LS_NormalTemperatura TEM2 = new LS_NormalTemperatura();
		TEM2.adiFinal(new Temperatura(42));
		TEM2.adiFinal(new Temperatura(26));
		TEM2.adiFinal(new Temperatura(-13));
		LS_NormalTemperatura TEM3 = new LS_NormalTemperatura();
		TEM3.adiFinal(new Temperatura(18));
		TEM3.adiFinal(new Temperatura(-5));
		TEM3.adiFinal(new Temperatura(21));
		TEM3.adiFinal(new Temperatura(-16));
		TEM3.adiFinal(new Temperatura(8));
		TEM3.adiFinal(new Temperatura(3));
		LS_NormalTemperatura TEM4 = new LS_NormalTemperatura();
		TEM4.adiFinal(new Temperatura(2));
		TEM4.adiFinal(new Temperatura(19));
		TEM4.adiFinal(new Temperatura(-11));
		TEM4.adiFinal(new Temperatura(14));
		LS_NormalTemperatura TEM5 = new LS_NormalTemperatura();
		TEM5.adiFinal(new Temperatura(18));
		TEM5.adiFinal(new Temperatura(-5));
		LS_NormalTemperatura TEM6 = new LS_NormalTemperatura();
		TEM6.adiFinal(new Temperatura(21));
		TEM6.adiFinal(new Temperatura(33));
		TEM6.adiFinal(new Temperatura(10));
		TEM6.adiFinal(new Temperatura(-1));
		TEM6.adiFinal(new Temperatura(0));
		LS_NormalTemperatura TEM7 = new LS_NormalTemperatura();
		TEM7.adiFinal(new Temperatura(23));
		TEM7.adiFinal(new Temperatura(32));
		TEM7.adiFinal(new Temperatura(41));
		TEM7.adiFinal(new Temperatura(21));
		LS_NormalTemperatura TEM8 = new LS_NormalTemperatura();
		TEM8.adiFinal(new Temperatura(4));
		TEM8.adiFinal(new Temperatura(-7));
		LS_NormalTemperatura TEM9 = new LS_NormalTemperatura();
		TEM9.adiFinal(new Temperatura(18));
		TEM9.adiFinal(new Temperatura(-5));
		TEM9.adiFinal(new Temperatura(21));
		TEM9.adiFinal(new Temperatura(16));
		LS_NormalTemperatura TEM10 = new LS_NormalTemperatura();
		TEM10.adiFinal(new Temperatura(-11));
		TEM10.adiFinal(new Temperatura(24));
		TEM10.adiFinal(new Temperatura(30));
		TEM10.adiFinal(new Temperatura(-13));
		TEM10.adiFinal(new Temperatura(-6));
		TEM10.adiFinal(new Temperatura(2));
		TEM10.adiFinal(new Temperatura(27));
		TEM10.adiFinal(new Temperatura(-2));
		TEM10.adiFinal(new Temperatura(0));
		TEM10.adiFinal(new Temperatura(1)); 
		LS_NormalTemperatura TEM11 = new LS_NormalTemperatura();
		TEM11.adiFinal(new Temperatura(17));
		TEM11.adiFinal(new Temperatura(10));
		TEM11.adiFinal(new Temperatura(-9));
		
		LS_NormalTemperatura TEM12 = new LS_NormalTemperatura();
		TEM12.adiFinal(new Temperatura(12));
		TEM12.adiFinal(new Temperatura(-5));
		TEM12.adiFinal(new Temperatura(23));
		TEM12.adiFinal(new Temperatura(0));
		TEM12.adiFinal(new Temperatura(39));
		LS_NormalTemperatura TEM13 = new LS_NormalTemperatura();
		TEM13.adiFinal(new Temperatura(-1));
		TEM13.adiFinal(new Temperatura(2));
		TEM13.adiFinal(new Temperatura(-3));
		LS_NormalTemperatura TEM14 = new LS_NormalTemperatura();
		TEM14.adiFinal(new Temperatura(21));
		TEM14.adiFinal(new Temperatura(17));
		LS_NormalTemperatura TEM15 = new LS_NormalTemperatura();
		TEM15.adiFinal(new Temperatura(-13));
		TEM15.adiFinal(new Temperatura(11));
		TEM15.adiFinal(new Temperatura(30));
		TEM15.adiFinal(new Temperatura(-18));
		TEM15.adiFinal(new Temperatura(10));
		TEM15.adiFinal(new Temperatura(0));
		LS_NormalTemperatura TEM16 = new LS_NormalTemperatura();
		TEM16.adiFinal(new Temperatura(-18));
		TEM16.adiFinal(new Temperatura(-2));
		TEM16.adiFinal(new Temperatura(7));
		LS_NormalTemperatura TEM17 = new LS_NormalTemperatura();
		TEM17.adiFinal(new Temperatura(40));
		TEM17.adiFinal(new Temperatura(26));
		LS_NormalTemperatura TEM18 = new LS_NormalTemperatura();
		TEM18.adiFinal(new Temperatura(-32));
		TEM18.adiFinal(new Temperatura(16));
		TEM18.adiFinal(new Temperatura(15));
		TEM18.adiFinal(new Temperatura(-7));
		LS_NormalTemperatura TEM19 = new LS_NormalTemperatura();
		TEM19.adiFinal(new Temperatura(27));
		TEM19.adiFinal(new Temperatura(-12));
		TEM19.adiFinal(new Temperatura(33));
		TEM19.adiFinal(new Temperatura(9));
		TEM19.adiFinal(new Temperatura(-2));
		TEM19.adiFinal(new Temperatura(32));
		TEM19.adiFinal(new Temperatura(17));
		LS_NormalTemperatura TEM20 = new LS_NormalTemperatura();
		TEM20.adiFinal(new Temperatura(25));
		TEM20.adiFinal(new Temperatura(39));
		LS_NormalTemperatura TEM21 = new LS_NormalTemperatura();
		TEM21.adiFinal(new Temperatura(14));
		TEM21.adiFinal(new Temperatura(13));
		TEM21.adiFinal(new Temperatura(31));
		LS_NormalTemperatura TEM22 = new LS_NormalTemperatura();
		TEM22.adiFinal(new Temperatura(-7));
		TEM22.adiFinal(new Temperatura(15));
		LS_NormalTemperatura TEM23 = new LS_NormalTemperatura();
		TEM23.adiFinal(new Temperatura(-6));
		TEM23.adiFinal(new Temperatura(5));
		TEM23.adiFinal(new Temperatura(-17));
		TEM23.adiFinal(new Temperatura(10));
		TEM23.adiFinal(new Temperatura(23));
		LS_NormalTemperatura TEM24 = new LS_NormalTemperatura();
		TEM24.adiFinal(new Temperatura(31));
		TEM24.adiFinal(new Temperatura(40));
		TEM24.adiFinal(new Temperatura(-2));
		LS_NormalTemperatura TEM25 = new LS_NormalTemperatura();
		TEM25.adiFinal(new Temperatura(0));
		TEM25.adiFinal(new Temperatura(18));
		TEM25.adiFinal(new Temperatura(-19));
		TEM25.adiFinal(new Temperatura(5));
		LS_NormalTemperatura TEM26 = new LS_NormalTemperatura();
		TEM26.adiFinal(new Temperatura(20));
		TEM26.adiFinal(new Temperatura(24));
		LS_NormalTemperatura TEM27 = new LS_NormalTemperatura();
		TEM27.adiFinal(new Temperatura(-17));
		LS_NormalTemperatura TEM28 = new LS_NormalTemperatura();
		TEM28.adiFinal(new Temperatura(15));
		TEM28.adiFinal(new Temperatura(1));
		TEM28.adiFinal(new Temperatura(36));
		
		
		LD_NormalMeteorologia MET1 = new LD_NormalMeteorologia();
		MET1.adiFinal(new Meteorologia(TEM1, "23/01/2023",30,"15m/s"));
		MET1.adiFinal(new Meteorologia(TEM2, "30/05/2023",15,"45m/s"));
		LD_NormalMeteorologia MET2 = new LD_NormalMeteorologia();
		MET2.adiFinal(new Meteorologia(TEM3, "03/02/2023",20,"32m/s"));
		MET2.adiFinal(new Meteorologia(TEM4, "15/03/2023",80,"17m/s"));
		MET2.adiFinal(new Meteorologia(TEM5, "26/04/2023",10,"50m/s"));
		LD_NormalMeteorologia MET3 = new LD_NormalMeteorologia();
		MET3.adiFinal(new Meteorologia(TEM6, "12/01/2023",63,"10m/s"));
		MET3.adiFinal(new Meteorologia(TEM7, "02/03/2023",40,"12m/s"));
		MET3.adiFinal(new Meteorologia(TEM8, "16/05/2023",35,"18m/s"));
		MET3.adiFinal(new Meteorologia(TEM9, "30/07/2023",17,"7m/s"));
		LD_NormalMeteorologia MET4 = new LD_NormalMeteorologia();
		MET4.adiFinal(new Meteorologia(TEM10, "05/06/2023",21,"26m/s"));
		MET4.adiFinal(new Meteorologia(TEM11, "08/10/2023",27,"24m/s"));
		
		LD_NormalMeteorologia MET5 = new LD_NormalMeteorologia();
		MET5.adiFinal(new Meteorologia(TEM12, "19/06/2023",47,"15m/s"));
		MET5.adiFinal(new Meteorologia(TEM13, "12/07/2023",16,"7m/s"));
		MET5.adiFinal(new Meteorologia(TEM14, "31/10/2023",36,"16m/s"));
		LD_NormalMeteorologia MET6 = new LD_NormalMeteorologia();
		MET6.adiFinal(new Meteorologia(TEM15, "01/01/2023",32,"9m/s"));
		MET6.adiFinal(new Meteorologia(TEM16, "23/03/2023",11,"12m/s"));
		LD_NormalMeteorologia MET7 = new LD_NormalMeteorologia();
		MET7.adiFinal(new Meteorologia(TEM17, "10/02/2023",80,"6m/s"));
		MET7.adiFinal(new Meteorologia(TEM18, "31/05/2023",33,"18m/s"));
		MET7.adiFinal(new Meteorologia(TEM19, "21/07/2023",24,"20m/s"));
		MET7.adiFinal(new Meteorologia(TEM20, "18/09/2023",72,"4m/s"));
		LD_NormalMeteorologia MET8 = new LD_NormalMeteorologia();
		MET8.adiFinal(new Meteorologia(TEM21, "08/04/2023",9,"5m/s"));
		MET8.adiFinal(new Meteorologia(TEM22, "15/08/2023",40,"10m/s"));
		MET8.adiFinal(new Meteorologia(TEM23, "26/10/2023",56,"17m/s"));
		MET8.adiFinal(new Meteorologia(TEM24, "14/11/2023",20,"12m/s"));
		MET8.adiFinal(new Meteorologia(TEM25, "25/12/2023",29,"29m/s"));
		LD_NormalMeteorologia MET9 = new LD_NormalMeteorologia();
		MET9.adiFinal(new Meteorologia(TEM26, "13/02/2023",53,"33m/s"));
		MET9.adiFinal(new Meteorologia(TEM27, "29/07/2023",3,"14m/s"));
		MET9.adiFinal(new Meteorologia(TEM28, "21/09/2023",26,"13m/s"));
		
		LD_CircularContaminacion CON1 = new LD_CircularContaminacion();
		CON1.adiFinal(new Contaminacion("Suelo"));
		CON1.adiFinal(new Contaminacion("Aire"));
		CON1.adiFinal(new Contaminacion("Agua"));
		LD_CircularContaminacion CON2 = new LD_CircularContaminacion();
		CON2.adiFinal(new Contaminacion("Agua"));
		CON2.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON3 = new LD_CircularContaminacion();
		CON3.adiFinal(new Contaminacion("Suelo"));
		CON3.adiFinal(new Contaminacion("Aire"));
		CON3.adiFinal(new Contaminacion("Agua"));
		CON3.adiFinal(new Contaminacion("Agua"));
		CON3.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON4 = new LD_CircularContaminacion();
		CON4.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON5 = new LD_CircularContaminacion();
		CON5.adiFinal(new Contaminacion("Aire"));
		CON5.adiFinal(new Contaminacion("Agua"));
		CON5.adiFinal(new Contaminacion("Suelo"));
		CON5.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON6 = new LD_CircularContaminacion();
		CON6.adiFinal(new Contaminacion("Agua"));
		CON6.adiFinal(new Contaminacion("Suelo"));
		CON6.adiFinal(new Contaminacion("Aire"));
		LD_CircularContaminacion CON7 = new LD_CircularContaminacion();
		CON7.adiFinal(new Contaminacion("Suelo"));
		CON7.adiFinal(new Contaminacion("Suelo"));
		CON7.adiFinal(new Contaminacion("Agua"));
		CON7.adiFinal(new Contaminacion("Aire"));
		CON7.adiFinal(new Contaminacion("Agua"));
		CON7.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON8 = new LD_CircularContaminacion();
		CON8.adiFinal(new Contaminacion("Agua"));
		CON8.adiFinal(new Contaminacion("Suelo"));
		CON8.adiFinal(new Contaminacion("Agua"));
		CON8.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON9 = new LD_CircularContaminacion();
		CON9.adiFinal(new Contaminacion("Agua"));
		CON9.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON10 = new LD_CircularContaminacion();
		CON10.adiFinal(new Contaminacion("Aire"));
		CON10.adiFinal(new Contaminacion("Suelo"));
		CON10.adiFinal(new Contaminacion("Agua"));
		CON10.adiFinal(new Contaminacion("Suelo"));
		CON10.adiFinal(new Contaminacion("Aire"));
		LD_CircularContaminacion CON11 = new LD_CircularContaminacion();
		CON11.adiFinal(new Contaminacion("Suelo"));
		CON11.adiFinal(new Contaminacion("Suelo"));
		CON11.adiFinal(new Contaminacion("Agua"));
		CON11.adiFinal(new Contaminacion("Aire"));
		
		LD_CircularContaminacion CON12 = new LD_CircularContaminacion();
		CON12.adiFinal(new Contaminacion("Suelo"));
		CON12.adiFinal(new Contaminacion("Agua"));
		CON12.adiFinal(new Contaminacion("Agua"));
		LD_CircularContaminacion CON13 = new LD_CircularContaminacion();
		CON13.adiFinal(new Contaminacion("Aire"));
		CON13.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON14 = new LD_CircularContaminacion();
		CON14.adiFinal(new Contaminacion("Agua"));
		CON14.adiFinal(new Contaminacion("Suelo"));
		CON14.adiFinal(new Contaminacion("Suelo"));
		CON14.adiFinal(new Contaminacion("Aire"));
		CON14.adiFinal(new Contaminacion("Agua"));
		LD_CircularContaminacion CON15 = new LD_CircularContaminacion();
		CON15.adiFinal(new Contaminacion("Agua"));
		CON15.adiFinal(new Contaminacion("Aire"));
		CON15.adiFinal(new Contaminacion("Aire"));
		CON15.adiFinal(new Contaminacion("Suelo"));
		CON15.adiFinal(new Contaminacion("Agua"));
		CON15.adiFinal(new Contaminacion("Suelo"));
		CON15.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON16 = new LD_CircularContaminacion();
		CON16.adiFinal(new Contaminacion("Suelo"));
		CON16.adiFinal(new Contaminacion("Suelo"));
		CON16.adiFinal(new Contaminacion("Agua"));
		CON16.adiFinal(new Contaminacion("Aire"));
		CON16.adiFinal(new Contaminacion("Agua"));
		CON16.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON17 = new LD_CircularContaminacion();
		CON17.adiFinal(new Contaminacion("Agua"));
		CON17.adiFinal(new Contaminacion("Suelo"));
		CON17.adiFinal(new Contaminacion("Agua"));
		CON17.adiFinal(new Contaminacion("Aire"));
		LD_CircularContaminacion CON18 = new LD_CircularContaminacion();
		CON18.adiFinal(new Contaminacion("Aire"));
		CON18.adiFinal(new Contaminacion("Suelo"));
		CON18.adiFinal(new Contaminacion("Agua"));
		LD_CircularContaminacion CON19 = new LD_CircularContaminacion();
		CON19.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON20 = new LD_CircularContaminacion();
		CON20.adiFinal(new Contaminacion("Suelo"));
		CON20.adiFinal(new Contaminacion("Agua"));
		CON20.adiFinal(new Contaminacion("Aire"));
		CON20.adiFinal(new Contaminacion("Aire"));
		CON20.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON21 = new LD_CircularContaminacion();
		CON21.adiFinal(new Contaminacion("Agua"));
		CON21.adiFinal(new Contaminacion("Suelo"));
		CON21.adiFinal(new Contaminacion("Aire"));
		CON21.adiFinal(new Contaminacion("Aire"));
		CON21.adiFinal(new Contaminacion("Suelo"));
		CON21.adiFinal(new Contaminacion("Suelo"));
		LD_CircularContaminacion CON22 = new LD_CircularContaminacion();
		CON22.adiFinal(new Contaminacion("Aire"));
		CON22.adiFinal(new Contaminacion("Agua"));
		LD_CircularContaminacion CON23 = new LD_CircularContaminacion();
		CON23.adiFinal(new Contaminacion("Suelo"));
		CON23.adiFinal(new Contaminacion("Agua"));
		CON23.adiFinal(new Contaminacion("Agua"));
		CON23.adiFinal(new Contaminacion("Aire"));
		LD_CircularContaminacion CON24 = new LD_CircularContaminacion();
		CON24.adiFinal(new Contaminacion("Aire"));
		CON24.adiFinal(new Contaminacion("Suelo"));
		CON24.adiFinal(new Contaminacion("Agua"));
		
		LS_NormalPrevencionContaminacion PREV1 = new LS_NormalPrevencionContaminacion();
		PREV1.adiFinal(CON1, 3,"Cuida tu ciudad!!");
		PREV1.adiFinal(CON2, 2,"Cuida tu ciudad!!");
		PREV1.adiFinal(CON3, 5,"Cuida tu ciudad!!");
		LS_NormalPrevencionContaminacion PREV2 = new LS_NormalPrevencionContaminacion();
		PREV2.adiFinal(CON4, 1,"Cuida tu ciudad!!");
		PREV2.adiFinal(CON5, 4,"Cuida tu ciudad!!");
		PREV2.adiFinal(CON6, 3,"Cuida tu ciudad!!");
		PREV2.adiFinal(CON7, 6,"Cuida tu ciudad!!");
		LS_NormalPrevencionContaminacion PREV3 = new LS_NormalPrevencionContaminacion();
		PREV3.adiFinal(CON8, 4,"Cuida tu ciudad!!");
		PREV3.adiFinal(CON9, 2,"Cuida tu ciudad!!");
		LS_NormalPrevencionContaminacion PREV4 = new LS_NormalPrevencionContaminacion();
		PREV4.adiFinal(CON10, 5,"Cuida tu ciudad!!");
		PREV4.adiFinal(CON11, 4,"Cuida tu ciudad!!");
		
		LS_NormalPrevencionContaminacion PREV5 = new LS_NormalPrevencionContaminacion();
		PREV5.adiFinal(CON12, 3,"Cuida tu ciudad!!");
		PREV5.adiFinal(CON13, 2,"Cuida tu ciudad!!");
		PREV5.adiFinal(CON14, 5,"Cuida tu ciudad!!");
		PREV5.adiFinal(CON15, 7,"Cuida tu ciudad!!");
		LS_NormalPrevencionContaminacion PREV6 = new LS_NormalPrevencionContaminacion();
		PREV6.adiFinal(CON16, 6,"Cuida tu ciudad!!");
		LS_NormalPrevencionContaminacion PREV7 = new LS_NormalPrevencionContaminacion();
		PREV7.adiFinal(CON17, 4,"Cuida tu ciudad!!");
		PREV7.adiFinal(CON18, 3,"Cuida tu ciudad!!");
		PREV7.adiFinal(CON19, 1,"Cuida tu ciudad!!");
		LS_NormalPrevencionContaminacion PREV8 = new LS_NormalPrevencionContaminacion();
		PREV8.adiFinal(CON20, 5,"Cuida tu ciudad!!");
		PREV8.adiFinal(CON21, 6,"Cuida tu ciudad!!");
		LS_NormalPrevencionContaminacion PREV9 = new LS_NormalPrevencionContaminacion();
		PREV9.adiFinal(CON22, 2,"Cuida tu ciudad!!");
		PREV9.adiFinal(CON23, 4,"Cuida tu ciudad!!");
		PREV9.adiFinal(CON24, 3,"Cuida tu ciudad!!");
		
		//TERREMOTO
		LS_CircularRescate RESC1 = new LS_CircularRescate();
		RESC1.adiFinal(new Rescate("Rescate en estructuras colapsadas"));
		RESC1.adiFinal(new Rescate("Rescate con perros de busqueda"));
		RESC1.adiFinal(new Rescate("Rescate en espacios confinados"));
		//HURACAN
		LS_CircularRescate RESC2 = new LS_CircularRescate();
		RESC2.adiFinal(new Rescate("Rescate en inundaciones"));
		RESC2.adiFinal(new Rescate("Rescate aereo"));
		RESC2.adiFinal(new Rescate("Evacuacion de emergencia"));
		//INUNDACION
		LS_CircularRescate RESC3 = new LS_CircularRescate();
		RESC3.adiFinal(new Rescate("Rescate acuatico"));
		RESC3.adiFinal(new Rescate("Rescate con botes"));
		RESC3.adiFinal(new Rescate("Rescate aereo"));
		//INCENDIO FORESTAL
		LS_CircularRescate RESC4 = new LS_CircularRescate();
		RESC4.adiFinal(new Rescate("Rescate con equipos de bomberos"));
		RESC4.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC4.adiFinal(new Rescate("Rescate aereo"));
		//TSUNAMI
		LS_CircularRescate RESC5 = new LS_CircularRescate();
		RESC5.adiFinal(new Rescate("Rescate acuatico"));
		RESC5.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC5.adiFinal(new Rescate("Rescate aereo"));
		//HURACAN
		LS_CircularRescate RESC6 = new LS_CircularRescate();
		RESC6.adiFinal(new Rescate("Rescate en inundaciones"));
		RESC6.adiFinal(new Rescate("Rescate aereo"));
		RESC6.adiFinal(new Rescate("Evacuacion de emergencia"));
		//DESLIZAMIENTO DE TIERRA
		LS_CircularRescate RESC7 = new LS_CircularRescate();
		RESC7.adiFinal(new Rescate("Rescate en estructuras colapsadas"));
		RESC7.adiFinal(new Rescate("Rescate en terrenos inestables"));
		RESC7.adiFinal(new Rescate("Busqueda y rescate en escombros"));
		//ERUPCION VOLCANICA
		LS_CircularRescate RESC8 = new LS_CircularRescate();
		RESC8.adiFinal(new Rescate("Rescate en zonas de alta temperatura"));
		RESC8.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC8.adiFinal(new Rescate("Rescate aereo"));
		//TERREMOTO
		LS_CircularRescate RESC9 = new LS_CircularRescate();
		RESC9.adiFinal(new Rescate("Rescate en estructuras colapsadas"));
		RESC9.adiFinal(new Rescate("Rescate con perros de busqueda"));
		RESC9.adiFinal(new Rescate("Rescate en espacios confinados"));
		//TSUNAMI
		LS_CircularRescate RESC10 = new LS_CircularRescate();
		RESC10.adiFinal(new Rescate("Rescate acuatico"));
		RESC10.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC10.adiFinal(new Rescate("Rescate aereo"));
		//ERUPCION VOLCANICA
		LS_CircularRescate RESC11 = new LS_CircularRescate();
		RESC11.adiFinal(new Rescate("Rescate en zonas de alta temperatura"));
		RESC11.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC11.adiFinal(new Rescate("Rescate aereo"));
		//TERREMOTO
		LS_CircularRescate RESC12 = new LS_CircularRescate();
		RESC12.adiFinal(new Rescate("Rescate en estructuras colapsadas"));
		RESC12.adiFinal(new Rescate("Rescate con perros de busqueda"));
		RESC12.adiFinal(new Rescate("Rescate en espacios confinados"));
		//TSUNAMI
		LS_CircularRescate RESC13 = new LS_CircularRescate();
		RESC13.adiFinal(new Rescate("Rescate acuatico"));
		RESC13.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC13.adiFinal(new Rescate("Rescate aereo"));
		
		//ERUPCION VOLCANICA
		LS_CircularRescate RESC14 = new LS_CircularRescate();
		RESC14.adiFinal(new Rescate("Rescate en zonas de alta temperatura"));
		RESC14.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC14.adiFinal(new Rescate("Rescate aereo"));
		//TERREMOTO
		LS_CircularRescate RESC15 = new LS_CircularRescate();
		RESC15.adiFinal(new Rescate("Rescate en estructuras colapsadas"));
		RESC15.adiFinal(new Rescate("Rescate con perros de busqueda"));
		RESC15.adiFinal(new Rescate("Rescate en espacios confinados"));
		//INUNDACION
		LS_CircularRescate RESC16 = new LS_CircularRescate();
		RESC16.adiFinal(new Rescate("Rescate acuatico"));
		RESC16.adiFinal(new Rescate("Rescate con botes"));
		RESC16.adiFinal(new Rescate("Rescate aereo"));
		//DESLIZAMIENTO DE TIERRA
		LS_CircularRescate RESC17 = new LS_CircularRescate();
		RESC17.adiFinal(new Rescate("Rescate en estructuras colapsadas"));
		RESC17.adiFinal(new Rescate("Rescate en terrenos inestables"));
		RESC17.adiFinal(new Rescate("Busqueda y rescate en escombros"));
		//TSUNAMI
		LS_CircularRescate RESC18 = new LS_CircularRescate();
		RESC18.adiFinal(new Rescate("Rescate acuatico"));
		RESC18.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC18.adiFinal(new Rescate("Rescate aereo"));
		//INCENDIO FORESTAL
		LS_CircularRescate RESC19 = new LS_CircularRescate();
		RESC19.adiFinal(new Rescate("Rescate con equipos de bomberos"));
		RESC19.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC19.adiFinal(new Rescate("Rescate aereo"));
		//HURACAN
		LS_CircularRescate RESC20 = new LS_CircularRescate();
		RESC20.adiFinal(new Rescate("Rescate en inundaciones"));
		RESC20.adiFinal(new Rescate("Rescate aereo"));
		RESC20.adiFinal(new Rescate("Evacuacion de emergencia"));
		//ERUPCION VOLCANICA
		LS_CircularRescate RESC21 = new LS_CircularRescate();
		RESC21.adiFinal(new Rescate("Rescate en zonas de alta temperatura"));
		RESC21.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC21.adiFinal(new Rescate("Rescate aereo"));
		//DESLIZAMIENTO DE TIERRA
		LS_CircularRescate RESC22 = new LS_CircularRescate();
		RESC22.adiFinal(new Rescate("Rescate en estructuras colapsadas"));
		RESC22.adiFinal(new Rescate("Rescate en terrenos inestables"));
		RESC22.adiFinal(new Rescate("Busqueda y rescate en escombros"));
		//INCENDIO FORESTAL
		LS_CircularRescate RESC23 = new LS_CircularRescate();
		RESC23.adiFinal(new Rescate("Rescate con equipos de bomberos"));
		RESC23.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC23.adiFinal(new Rescate("Rescate aereo"));
		//TSUNAMI
		LS_CircularRescate RESC24 = new LS_CircularRescate();
		RESC24.adiFinal(new Rescate("Rescate acuatico"));
		RESC24.adiFinal(new Rescate("Evacuacion de emergencia"));
		RESC24.adiFinal(new Rescate("Rescate aereo"));
		//HURACAN
		LS_CircularRescate RESC25 = new LS_CircularRescate();
		RESC25.adiFinal(new Rescate("Rescate en inundaciones"));
		RESC25.adiFinal(new Rescate("Rescate aereo"));
		RESC25.adiFinal(new Rescate("Evacuacion de emergencia"));
		//TERREMOTO
		LS_CircularRescate RESC26 = new LS_CircularRescate();
		RESC26.adiFinal(new Rescate("Rescate en estructuras colapsadas"));
		RESC26.adiFinal(new Rescate("Rescate con perros de busqueda"));
		RESC26.adiFinal(new Rescate("Rescate en espacios confinados"));
		
		
		ColaCircularDesastreNatural CDN1 = new ColaCircularDesastreNatural();
		CDN1.adi(new DesastreNatural("Terremoto",RESC1));
		CDN1.adi(new DesastreNatural("Huracan",RESC2));
		CDN1.adi(new DesastreNatural("Inundacion",RESC3));
		ColaCircularDesastreNatural CDN2 = new ColaCircularDesastreNatural();
		CDN2.adi(new DesastreNatural("Incendio Forestal",RESC4));
		CDN2.adi(new DesastreNatural("Tsunami",RESC5));
		CDN2.adi(new DesastreNatural("Huracan",RESC6));
		ColaCircularDesastreNatural CDN3 = new ColaCircularDesastreNatural();
		CDN3.adi(new DesastreNatural("Deslizamiento de tierra",RESC7));
		CDN3.adi(new DesastreNatural("Erupcion Volcanica",RESC8));
		CDN3.adi(new DesastreNatural("Terremoto",RESC9));
		CDN3.adi(new DesastreNatural("Tsunami",RESC10));
		ColaCircularDesastreNatural CDN4 = new ColaCircularDesastreNatural();
		CDN4.adi(new DesastreNatural("Erupcion Volcanica",RESC11));
		CDN4.adi(new DesastreNatural("Terremoto",RESC12));
		CDN4.adi(new DesastreNatural("Tsunami",RESC13));
		
		ColaCircularDesastreNatural CDN5 = new ColaCircularDesastreNatural();
		CDN5.adi(new DesastreNatural("Erupcion Volcanica",RESC14));
		ColaCircularDesastreNatural CDN6 = new ColaCircularDesastreNatural();
		CDN6.adi(new DesastreNatural("Terremoto",RESC15));
		CDN6.adi(new DesastreNatural("Inundacion",RESC16));
		CDN6.adi(new DesastreNatural("Deslizamiento de tierra",RESC17));
		ColaCircularDesastreNatural CDN7 = new ColaCircularDesastreNatural();
		CDN7.adi(new DesastreNatural("Huracan",RESC18));
		CDN7.adi(new DesastreNatural("Incendio Forestal",RESC19));
		ColaCircularDesastreNatural CDN8 = new ColaCircularDesastreNatural();
		CDN8.adi(new DesastreNatural("Huracan",RESC20));
		CDN8.adi(new DesastreNatural("Erupcion Volcanica",RESC21));
		CDN8.adi(new DesastreNatural("Deslizamiento de tierra",RESC22));
		ColaCircularDesastreNatural CDN9 = new ColaCircularDesastreNatural();
		CDN9.adi(new DesastreNatural("Incendio Forestal",RESC23));
		CDN9.adi(new DesastreNatural("Tsunami",RESC24));
		CDN9.adi(new DesastreNatural("Huracan",RESC25));
		CDN9.adi(new DesastreNatural("Terremoto",RESC26));
		
		
		Departamento dep1= new Departamento("La Paz","La Paz",2000,"Lp02","Min 5C/Max 21C","Alto",MET1,PREV1,CDN1);
		Departamento dep2 = new Departamento("Beni","Trinidad",1050,"Ben08","Min 17C/Max 29C","Medio",MET2,PREV2,CDN2);
		Departamento dep3 = new Departamento("Chuquisaca","Sucre",1500,"Ch01","Min -6C/Max 16C","Alto",MET3,PREV3,CDN3);
		Departamento dep4 = new Departamento("Santa Cruz","Santa Cruz de la Sierra",2500,"Scz07","Min 16C/Max 28C","Bajo",MET4,PREV4,CDN4);
		Departamento dep5 = new Departamento("Pando","Cobija",1100,"Pnd09","Min 8C/Max 32C","Alto",MET5,PREV5,CDN5);
		Departamento dep6 = new Departamento("Tarija","Tarija",4300,"Tja06","Min 9C/Max 25C","Medio",MET6,PREV6,CDN6);
		Departamento dep7 = new Departamento("Cochabamba","Cochabamba",1780,"Cbba03","Min 4C/Max 22C","Medio",MET7,PREV7,CDN7);
		Departamento dep8 = new Departamento("Oruro","Oruro",4940,"Or04","Min -6C/Max 16C","Alto",MET8,PREV8,CDN8);
		Departamento dep9 = new Departamento("Potosi","Potosi",2600,"Pt05","Min -3C/Max 4C","Bajo",MET9,PREV9,CDN9);
		
                //LS_NormalDepartamento Depa = new LS_NormalDepartamento();
		this.adiFinal(dep1);
		this.adiFinal(dep2);
		this.adiFinal(dep3);
		this.adiFinal(dep4);
		this.adiFinal(dep5);
		this.adiFinal(dep6);
		this.adiFinal(dep7);
		this.adiFinal(dep8);
		this.adiFinal(dep9);
        }
        
	
	public void leer2(int n) {
		for(int i = 1; i <= n; i++) {
			Departamento z = new Departamento();
			z.leer();
			adiFinal(z);
		}
	}
}
