package Clases;

public class ListaSimplePrevencionContaminacion {
	protected NodoPrevencionContaminacion P;
	
	public ListaSimplePrevencionContaminacion() {
		this.P = null;
	}

	public NodoPrevencionContaminacion getP() {
		return P;
	}

	public void setP(NodoPrevencionContaminacion p) {
		P = p;
	}
	
}
