package Clases;

public class ListaSimpleDepartamento {
	protected NodoDepartamento P;
	
	public ListaSimpleDepartamento() {
		this.P = null;
	}

	public NodoDepartamento getP() {
		return P;
	}

	public void setP(NodoDepartamento p) {
		P = p;
	}
	
}
