package Clases;

public class ListaSimpleTemperatura {
protected NodoTemperatura P;
	
	public ListaSimpleTemperatura() {
		this.P = null;
	}

	public NodoTemperatura getP() {
		return P;
	}

	public void setP(NodoTemperatura p) {
		P = p;
	}
	
}
