package Clases;

public class ColaDesastreNatural extends VectorDesastreNatural{
	protected int fr;
	protected int fi;
	
	public ColaDesastreNatural() {
		this.fr = 0;
		this.fi = 0;
	}
}