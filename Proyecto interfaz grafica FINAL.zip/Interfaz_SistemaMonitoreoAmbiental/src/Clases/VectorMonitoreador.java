package Clases;

public class VectorMonitoreador {
	protected int max = 50;
	protected Monitoreador v[] = new Monitoreador[max];
}
