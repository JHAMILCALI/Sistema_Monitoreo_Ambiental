package Clases;

public class ListaDobleContaminacion {
	protected NodoContaminacion P;
	
	public ListaDobleContaminacion() {
		this.P = null;
	}

	public NodoContaminacion getP() {
		return P;
	}

	public void setP(NodoContaminacion p) {
		P = p;
	}
	
}