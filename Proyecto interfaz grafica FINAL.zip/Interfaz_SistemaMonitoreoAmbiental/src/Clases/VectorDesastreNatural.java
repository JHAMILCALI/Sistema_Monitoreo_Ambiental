package Clases;

public class VectorDesastreNatural {
	protected int max = 50;
	protected DesastreNatural v[] = new DesastreNatural[max];
}
