package Clases;

public class ListaSimpleRescate {
	protected NodoRescate P;
	
	public ListaSimpleRescate() {
		this.P = null;
	}

	public NodoRescate getP() {
		return P;
	}

	public void setP(NodoRescate p) {
		P = p;
	}
	
}
