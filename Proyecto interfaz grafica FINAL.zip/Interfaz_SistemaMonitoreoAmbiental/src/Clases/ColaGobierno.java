package Clases;

public class ColaGobierno extends VectorGobierno{
	protected int fr;
	protected int fi;
	
	public ColaGobierno() {
		this.fr = -1;
		this.fi = -1;
	}
}
