package Clases;

public class ListaDobleMeteorologia {
	protected NodoMeteorologia P;
	
	public ListaDobleMeteorologia() {
		this.P = null;
	}

	public NodoMeteorologia getP() {
		return P;
	}

	public void setP(NodoMeteorologia p) {
		P = p;
	}
	
}
