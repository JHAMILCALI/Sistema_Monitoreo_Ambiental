package Clases;

public class VectorGobierno {
	protected int max = 50;
	protected Gobierno v[] = new Gobierno[max];
}
